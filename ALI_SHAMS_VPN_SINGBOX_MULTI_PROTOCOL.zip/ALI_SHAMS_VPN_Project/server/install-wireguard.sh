#!/usr/bin/env bash
set -euo pipefail
# Run only on an Ubuntu VPS you own, as root.
if [[ $EUID -ne 0 ]]; then echo "Run with sudo"; exit 1; fi
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y wireguard iptables-persistent
umask 077
SERVER_PRIV=$(wg genkey)
SERVER_PUB=$(printf '%s' "$SERVER_PRIV" | wg pubkey)
CLIENT_PRIV=$(wg genkey)
CLIENT_PUB=$(printf '%s' "$CLIENT_PRIV" | wg pubkey)
WAN_IF=$(ip -o -4 route show to default | awk '{print $5}' | head -n1)
PUBLIC_IP=$(curl -4fsS https://api.ipify.org)
cat > /etc/wireguard/wg0.conf <<EOF
[Interface]
Address = 10.66.66.1/24
ListenPort = 51820
PrivateKey = $SERVER_PRIV
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -A FORWARD -o wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o $WAN_IF -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -D FORWARD -o wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o $WAN_IF -j MASQUERADE

[Peer]
PublicKey = $CLIENT_PUB
AllowedIPs = 10.66.66.2/32
EOF
echo 'net.ipv4.ip_forward=1' > /etc/sysctl.d/99-wireguard-forward.conf
sysctl --system >/dev/null
systemctl enable --now wg-quick@wg0
cat > /root/client.conf <<EOF
[Interface]
PrivateKey = $CLIENT_PRIV
Address = 10.66.66.2/32
DNS = 1.1.1.1

[Peer]
PublicKey = $SERVER_PUB
Endpoint = $PUBLIC_IP:51820
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25
EOF
chmod 600 /root/client.conf
echo "WireGuard installed. Client config: /root/client.conf"
echo "Ensure UDP 51820 is allowed in your cloud firewall/security list."
