package com.alishams.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.system.OsConstants
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import java.lang.reflect.Proxy
import java.net.NetworkInterface

class SingBoxVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.alishams.vpn.START"
        const val ACTION_STOP = "com.alishams.vpn.STOP"
        const val EXTRA_CONFIG = "config"
        const val ACTION_STATE = "com.alishams.vpn.STATE"
        const val EXTRA_OK = "ok"
        const val EXTRA_MESSAGE = "message"
        private const val CHANNEL = "ali_shams_vpn"
        private const val NOTIFICATION_ID = 7001
        @Volatile private var libboxSetupDone = false
    }

    private var commandServer: Any? = null
    private var tunFd: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCore()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_START) {
            val config = intent.getStringExtra(EXTRA_CONFIG).orEmpty()
            startForeground(NOTIFICATION_ID, makeNotification("در حال راه‌اندازی sing-box"))
            Thread {
                try {
                    stopCore()
                    startCore(config)
                    sendState(true, "موتور sing-box اجرا شد؛ در حال بررسی عبور اینترنت")
                } catch (e: Exception) {
                    Log.e("ALI-SHAMS", "sing-box start failed", e)
                    stopCore()
                    sendState(false, "خطای موتور sing-box: ${rootMessage(e)}")
                    stopSelf()
                }
            }.start()
        }
        return START_NOT_STICKY
    }

    private fun startCore(config: String) {
        require(config.trim().startsWith("{")) { "پیکربندی sing-box معتبر نیست" }
        val libbox = Class.forName("io.nekohasekai.libbox.Libbox")
        if (!libboxSetupDone) synchronized(SingBoxVpnService::class.java) {
            if (!libboxSetupDone) {
                val setupClass = Class.forName("io.nekohasekai.libbox.SetupOptions")
                val setup = setupClass.getDeclaredConstructor().newInstance()
                set(setup, "setBasePath", filesDir.absolutePath)
                val work = getExternalFilesDir(null) ?: filesDir
                set(setup, "setWorkingPath", work.absolutePath)
                set(setup, "setTempPath", cacheDir.absolutePath)
                set(setup, "setLogMaxLines", 1000)
                set(setup, "setDebug", false)
                libbox.getMethod("setup", setupClass).invoke(null, setup)
                libboxSetupDone = true
            }
        }

        val platformClass = Class.forName("io.nekohasekai.libbox.PlatformInterface")
        val handlerClass = Class.forName("io.nekohasekai.libbox.CommandServerHandler")
        val platform = Proxy.newProxyInstance(platformClass.classLoader, arrayOf(platformClass)) { proxyObject, method, args ->
            if (method.declaringClass == Any::class.java) objectMethod(proxyObject, method.name, args) else
                platformCall(method.name, method.returnType, args ?: emptyArray())
        }
        val handler = Proxy.newProxyInstance(handlerClass.classLoader, arrayOf(handlerClass)) { proxyObject, method, args ->
            if (method.declaringClass == Any::class.java) objectMethod(proxyObject, method.name, args) else when (method.name) {
                "serviceStop" -> { stopCore(); stopSelf(); null }
                "serviceReload" -> null
                "getSystemProxyStatus" -> Class.forName("io.nekohasekai.libbox.SystemProxyStatus").getDeclaredConstructor().newInstance()
                "setSystemProxyEnabled", "triggerNativeCrash", "writeDebugMessage" -> null
                "connectSSHAgent" -> -1
                else -> defaultValue(method.returnType)
            }
        }
        val serverClass = Class.forName("io.nekohasekai.libbox.CommandServer")
        val constructor = serverClass.constructors.firstOrNull { it.parameterTypes.size == 2 }
            ?: error("سازنده CommandServer پیدا نشد")
        val server = constructor.newInstance(handler, platform)
        commandServer = server
        serverClass.getMethod("start").invoke(server)
        val overrideClass = Class.forName("io.nekohasekai.libbox.OverrideOptions")
        val override = overrideClass.getDeclaredConstructor().newInstance()
        serverClass.getMethod("startOrReloadService", String::class.java, overrideClass)
            .invoke(server, config, override)
    }

    private fun objectMethod(proxyObject: Any, name: String, args: Array<out Any?>?): Any? = when (name) {
        "toString" -> "ALI SHAMS sing-box platform bridge"
        "hashCode" -> System.identityHashCode(proxyObject)
        "equals" -> proxyObject === args?.firstOrNull()
        else -> null
    }

    private fun platformCall(name: String, returnType: Class<*>, args: Array<out Any?>): Any? {
        return when (name) {
            "usePlatformAutoDetectInterfaceControl" -> true
            "autoDetectInterfaceControl" -> {
                val fd = (args.firstOrNull() as? Number)?.toInt()
                if (fd != null && !protect(fd)) error("VPN protect(fd) failed")
                null
            }
            "openTun" -> openTun(args.firstOrNull() ?: error("TunOptions missing"))
            "startDefaultInterfaceMonitor" -> {
                val listener = args.firstOrNull()
                runCatching {
                    val active = NetworkInterface.getNetworkInterfaces().toList().firstOrNull { it.isUp && !it.isLoopback }
                    if (listener != null && active != null) {
                        listener.javaClass.methods.firstOrNull { it.name == "updateDefaultInterface" && it.parameterTypes.size == 4 }
                            ?.invoke(listener, active.name, active.index, false, false)
                    }
                }
                null
            }
            "closeDefaultInterfaceMonitor", "clearDNSCache", "registerMyInterface", "startNeighborMonitor", "closeNeighborMonitor",
            "sendNotification", "cancelNotification" -> null
            "underNetworkExtension", "includeAllNetworks", "usePlatformShell", "usePlatformBridge", "usePlatformAutoRedirect" -> false
            "usePlatformInterface" -> true
            "readWIFIState", "localDNSTransport" -> null
            "findConnectionOwner" -> Class.forName("io.nekohasekai.libbox.ConnectionOwner").getDeclaredConstructor().newInstance()
            "getInterfaces" -> networkInterfacesIterator()
            "lookupUser" -> Class.forName("io.nekohasekai.libbox.PlatformUser").getDeclaredConstructor().newInstance()
            "tailscaleHostname" -> "ALI-SHAMS-ANDROID"
            "processPlatformOptions" -> null
            else -> defaultValue(returnType)
        }
    }

    private fun openTun(options: Any): Int {
        val builder = Builder().setSession("ALI SHAMS VPN")
        val mtu = (get(options, "getMtu") as? Number)?.toInt() ?: 1400
        builder.setMtu(mtu)
        if (Build.VERSION.SDK_INT >= 29) builder.setMetered(false)
        val ipv4Addresses = collectPrefixes(get(options, "getInet4Address"))
        val ipv6Addresses = collectPrefixes(get(options, "getInet6Address"))
        ipv4Addresses.forEach { builder.addAddress(it.first, it.second) }
        ipv6Addresses.forEach { builder.addAddress(it.first, it.second) }
        val autoRoute = get(options, "getAutoRoute") as? Boolean ?: true
        if (autoRoute) {
            var route4 = collectPrefixes(get(options, "getInet4RouteAddress"))
            var route6 = collectPrefixes(get(options, "getInet6RouteAddress"))
            if (route4.isEmpty()) route4 = collectPrefixes(get(options, "getInet4RouteRange"))
            if (route6.isEmpty()) route6 = collectPrefixes(get(options, "getInet6RouteRange"))
            if (route4.isEmpty() && ipv4Addresses.isNotEmpty()) route4 = listOf("0.0.0.0" to 0)
            if (route6.isEmpty() && ipv6Addresses.isNotEmpty()) route6 = listOf("::" to 0)
            route4.forEach { builder.addRoute(it.first, it.second) }
            route6.forEach { builder.addRoute(it.first, it.second) }
            forEachIterator(get(options, "getDnsServerAddress")) { value -> runCatching { builder.addDnsServer(value.substringBefore('/')) } }
        }
        forEachIterator(get(options, "getIncludePackage")) { value -> runCatching { builder.addAllowedApplication(value) } }
        forEachIterator(get(options, "getExcludePackage")) { value -> runCatching { builder.addDisallowedApplication(value) } }
        val pfd = builder.establish() ?: error("Android VPN establish() failed")
        tunFd?.close()
        tunFd = pfd
        return pfd.fd
    }

    private fun collectPrefixes(iterator: Any?): List<Pair<String, Int>> {
        val result = mutableListOf<Pair<String, Int>>()
        if (iterator == null) return result
        runCatching {
            val hasNext = iterator.javaClass.getMethod("hasNext")
            val next = iterator.javaClass.getMethod("next")
            var count = 0
            while ((hasNext.invoke(iterator) as? Boolean) == true && count++ < 256) {
                val item = next.invoke(iterator) ?: continue
                val address: String
                val prefix: Int
                if (item is String) {
                    val parts = item.split("/")
                    if (parts.size != 2) continue
                    address = parts[0]
                    prefix = parts[1].toIntOrNull() ?: continue
                } else {
                    address = item.javaClass.methods.firstOrNull { it.name == "address" && it.parameterTypes.isEmpty() }?.invoke(item)?.toString() ?: continue
                    prefix = (item.javaClass.methods.firstOrNull { it.name == "prefix" && it.parameterTypes.isEmpty() }?.invoke(item) as? Number)?.toInt() ?: continue
                }
                result.add(address to prefix)
            }
        }.onFailure { Log.w("ALI-SHAMS", "prefix iterator error: ${it.message}") }
        return result
    }

    private fun forEachIterator(iterator: Any?, action: (String) -> Unit) {
        if (iterator == null) return
        runCatching {
            val hasNext = iterator.javaClass.getMethod("hasNext")
            val next = iterator.javaClass.getMethod("next")
            var count = 0
            while ((hasNext.invoke(iterator) as? Boolean) == true && count++ < 256) {
                val item = next.invoke(iterator)?.toString() ?: continue
                action(item)
            }
        }.onFailure { Log.w("ALI-SHAMS", "iterator error: ${it.message}") }
    }


    private fun networkInterfacesIterator(): Any {
        val ifaceClass = Class.forName("io.nekohasekai.libbox.NetworkInterface")
        val iteratorClass = Class.forName("io.nekohasekai.libbox.NetworkInterfaceIterator")
        val values = mutableListOf<Any>()
        val cm = getSystemService(ConnectivityManager::class.java)
        val networkInfo = mutableMapOf<String, Pair<android.net.LinkProperties, NetworkCapabilities>>()
        cm.allNetworks.forEach { network ->
            val lp = cm.getLinkProperties(network)
            val caps = cm.getNetworkCapabilities(network)
            if (lp?.interfaceName != null && caps != null) networkInfo[lp.interfaceName!!] = lp to caps
        }
        val all = runCatching { NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList() }.getOrDefault(emptyList())
        val libbox = Class.forName("io.nekohasekai.libbox.Libbox")
        all.filter { runCatching { it.isUp && !it.isLoopback }.getOrDefault(false) }.forEach { ni ->
            val item = ifaceClass.getDeclaredConstructor().newInstance()
            val (lp, caps) = networkInfo[ni.name] ?: (null to null)
            set(item, "setName", ni.name)
            set(item, "setIndex", ni.index)
            set(item, "setMtu", runCatching { ni.mtu }.getOrDefault(1500))
            set(item, "setFlags", OsConstants.IFF_UP or OsConstants.IFF_RUNNING)
            set(item, "setMetered", caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == false)
            val addrs = ni.interfaceAddresses.mapNotNull { a -> a.address?.hostAddress?.let { "$it/${a.networkPrefixLength}" } }
            set(item, "setAddresses", stringIterator(addrs))
            set(item, "setDnsServer", stringIterator(lp?.dnsServers?.mapNotNull { it.hostAddress } ?: emptyList()))
            set(item, "setDnsSearchDomain", stringIterator(lp?.domains?.split(' ')?.filter { it.isNotBlank() } ?: emptyList()))
            val gateways = lp?.routes?.filter { it.destination.prefixLength == 0 }?.mapNotNull { it.gateway?.hostAddress } ?: emptyList()
            set(item, "setGateway", stringIterator(gateways))
            val typeField = when {
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "InterfaceTypeWIFI"
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "InterfaceTypeCellular"
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "InterfaceTypeEthernet"
                else -> "InterfaceTypeOther"
            }
            val type = runCatching { libbox.getField(typeField).getInt(null) }.getOrDefault(0)
            set(item, "setType", type)
            values.add(item)
        }
        var index = 0
        return Proxy.newProxyInstance(iteratorClass.classLoader, arrayOf(iteratorClass)) { _, method, _ ->
            when (method.name) {
                "hasNext" -> index < values.size
                "next" -> values.getOrNull(index++)
                "len" -> values.size
                else -> defaultValue(method.returnType)
            }
        }
    }

    private fun stringIterator(values: List<String>): Any {
        val c = Class.forName("io.nekohasekai.libbox.StringIterator")
        val iterator = values.iterator()
        return Proxy.newProxyInstance(c.classLoader, arrayOf(c)) { _, method, _ ->
            when (method.name) {
                "hasNext" -> iterator.hasNext()
                "next" -> if (iterator.hasNext()) iterator.next() else ""
                "len" -> values.size
                else -> defaultValue(method.returnType)
            }
        }
    }

    private fun emptyIteratorProxy(className: String): Any {
        val c = Class.forName(className)
        return Proxy.newProxyInstance(c.classLoader, arrayOf(c)) { _, method, _ ->
            when (method.name) { "hasNext" -> false; "len" -> 0; else -> defaultValue(method.returnType) }
        }
    }

    private fun get(target: Any, getter: String): Any? =
        runCatching { target.javaClass.methods.firstOrNull { it.name == getter && it.parameterTypes.isEmpty() }?.invoke(target) }.getOrNull()

    private fun set(target: Any, setter: String, value: Any) {
        target.javaClass.methods.firstOrNull { it.name == setter && it.parameterTypes.size == 1 }?.invoke(target, value)
    }

    private fun defaultValue(type: Class<*>): Any? = when (type) {
        java.lang.Boolean.TYPE -> false
        java.lang.Integer.TYPE, java.lang.Short.TYPE, java.lang.Byte.TYPE -> 0
        java.lang.Long.TYPE -> 0L
        java.lang.Float.TYPE -> 0f
        java.lang.Double.TYPE -> 0.0
        java.lang.Character.TYPE -> '\u0000'
        java.lang.Void.TYPE -> null
        else -> null
    }

    @Suppress("DEPRECATION")
    private fun makeNotification(text: String): Notification {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "ALI SHAMS VPN", NotificationManager.IMPORTANCE_LOW))
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
            .setContentTitle("ALI SHAMS VPN").setContentText(text).setSmallIcon(android.R.drawable.stat_sys_warning).setOngoing(true).build()
        else Notification.Builder(this).setContentTitle("ALI SHAMS VPN")
            .setContentText(text).setSmallIcon(android.R.drawable.stat_sys_warning).setOngoing(true).build()
    }

    private fun sendState(ok: Boolean, message: String) {
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra(EXTRA_OK, ok).putExtra(EXTRA_MESSAGE, message))
    }

    private fun stopCore() {
        runCatching {
            commandServer?.let {
                it.javaClass.getMethod("closeService").invoke(it)
                it.javaClass.getMethod("close").invoke(it)
            }
        }.onFailure { Log.w("ALI-SHAMS", "close core: ${it.message}") }
        commandServer = null
        tunFd?.close()
        tunFd = null
    }

    private fun rootMessage(t: Throwable): String {
        var x: Throwable = t
        while (x.cause != null && x.cause !== x) x = x.cause!!
        return x.message ?: x.javaClass.simpleName
    }

    override fun onRevoke() {
        stopCore()
        sendState(false, "مجوز VPN از تنظیمات اندروید لغو شد.")
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() { stopCore(); super.onDestroy() }
}
