plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.alishams.vpn"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.alishams.vpn"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "3.0-singbox"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.github.singbox-android:libbox:1.14.0")
    implementation("androidx.core:core-ktx:1.15.0")
}
