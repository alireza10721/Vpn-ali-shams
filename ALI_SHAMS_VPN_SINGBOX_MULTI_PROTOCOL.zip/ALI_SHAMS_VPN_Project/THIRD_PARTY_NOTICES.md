# Third-party notices

ALI SHAMS VPN integrates `libbox` from the sing-box project.

- Android library: https://github.com/singbox-android/libbox
- Core project: https://github.com/SagerNet/sing-box
- Android reference implementation: https://github.com/SagerNet/sing-box-for-android

The sing-box/libbox components are distributed under GPL-3.0-or-later. Keep the corresponding source code and license notices with any distribution of an APK containing libbox. Review the upstream license files before redistribution.
