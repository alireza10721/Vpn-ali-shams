# ALI SHAMS VPN — نسخه آزمایشی موتور sing-box

این پروژه نسخه بازطراحی‌شده Android است که موتور WireGuard قبلی را با کتابخانه Android `libbox` از پروژه sing-box جایگزین می‌کند.

## پروتکل‌های قابل تبدیل در این نسخه

- VLESS (شامل پارامترهای TLS و Reality پایه)
- VMess (TCP، WebSocket و gRPC پایه)
- Trojan
- Shadowsocks
- Hysteria2
- TUIC
- AnyTLS
- WireGuard استاندارد

## ساخت APK با GitHub Actions

1. محتوای این ZIP را در ریشه مخزن GitHub قرار بده، به‌طوری‌که پوشه‌های `app` و `.github` در ریشه باشند.
2. فایل workflow در `.github/workflows/build.yml` را اجرا کن.
3. خروجی در Artifacts با نام `ALI-SHAMS-VPN-debug-apk` قرار می‌گیرد.

نیازمندی‌ها: JDK 17 و Gradle 8.9. وابستگی libbox از JitPack دریافت می‌شود؛ بنابراین ساخت اول به اینترنت نیاز دارد و ممکن است به علت دریافت کتابخانه حجیم کمی طول بکشد.

## منابع عمومی

برنامه از چند آدرس عمومی GitHub برای دریافت subscriptionهای رایگان استفاده می‌کند. عمومی بودن کانفیگ به معنی تضمین رایگان‌بودن دائمی، در دسترس بودن یا امنیت آن نیست. کانفیگ‌ها ممکن است حذف، منقضی یا از کار بیفتند.

## وضعیت تست

این سورس در محیط فعلی Android SDK/Gradle قابل کامپایل محلی نبود؛ بنابراین هنوز APK کامپایل‌شده و روی دستگاه واقعی تأیید نشده است. GitHub Actions باید اولین کامپایل را انجام دهد. همچنین پینگ ICMP فقط پاسخ شبکه را اندازه می‌گیرد و به‌تنهایی سلامت VPN را ثابت نمی‌کند. برنامه پس از راه‌اندازی موتور، عبور HTTP/HTTPS را از داخل تونل آزمایش می‌کند و فقط در صورت موفقیت وضعیت اتصال را سبز می‌کند.

## مجوز و انتساب

این پروژه از `libbox` متعلق به sing-box استفاده می‌کند. libbox و sing-box تحت GPL-3.0-or-later منتشر می‌شوند. توزیع نسخه‌ای که libbox را در خود دارد باید الزامات مجوز GPL، شامل ارائه کد منبع متناظر و حفظ اعلان‌های حق نشر و مجوز را رعایت کند.

- libbox: https://github.com/singbox-android/libbox
- sing-box: https://github.com/SagerNet/sing-box
- Android client reference: https://github.com/SagerNet/sing-box-for-android
