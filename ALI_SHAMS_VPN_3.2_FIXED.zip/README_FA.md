# ALI SHAMS VPN — نسخه ۳.۲ (رفع کرش)

این پروژه نسخه بازطراحی‌شده Android است که موتور WireGuard قبلی را با کتابخانه Android `libbox` از پروژه sing-box جایگزین می‌کند.

## تغییرات نسخه ۳.۲ (رفع مشکل بسته‌شدن هنگام انتخاب سرور)

- به‌روزرسانی `libbox` به **۱.۱۴.۴**
- فعال‌سازی پرچم‌های مهم `PlatformInterface` برای پایداری روی اندروید (`usePlatformDefaultInterfaceMonitor` و ...)
- تنظیمات TUN امن‌تر: حذف `strict_route`، استفاده از `stack: mixed`
- بهبود لاگ‌های `ALI-SHAMS-TRACE` و مدیریت خطا
- تنظیمات packaging برای جلوگیری از مشکلات JNI در ساخت

## پروتکل‌های پشتیبانی‌شده

- VLESS (شامل پارامترهای TLS و Reality پایه)
- VMess (TCP، WebSocket و gRPC پایه)
- Trojan
- Shadowsocks
- Hysteria2
- TUIC
- AnyTLS
- WireGuard استاندارد

## ساخت APK با GitHub Actions (پیشنهادی)

1. یک مخزن جدید در GitHub بساز.
2. **محتوای داخل پوشه `ALI_SHAMS_VPN_Project`** را در **ریشه** مخزن قرار بده  
   (یعنی پوشه‌های `app` و `.github` و فایل‌های `build.gradle.kts` و ... باید در ریشه باشند، نه داخل زیرپوشه).
3. به تب **Actions** برو و workflow با نام **Build ALI SHAMS VPN APK** را اجرا کن (دکمه Run workflow).
4. بعد از اتمام ساخت، در بخش Artifacts فایل `ALI-SHAMS-VPN-debug-apk` را دانلود کن.

نیازمندی‌ها: JDK 17 و Gradle 8.9. وابستگی libbox از JitPack دریافت می‌شود؛ ساخت اول به اینترنت نیاز دارد و ممکن است چند دقیقه طول بکشد.

## منابع عمومی

برنامه از چند آدرس عمومی GitHub برای دریافت subscriptionهای رایگان استفاده می‌کند. عمومی بودن کانفیگ به معنی تضمین رایگان‌بودن دائمی، در دسترس بودن یا امنیت آن نیست. کانفیگ‌ها ممکن است حذف، منقضی یا از کار بیفتند.

## اگر هنوز بسته شد

خروجی Logcat شامل تگ‌های `ALI-SHAMS` و `ALI-SHAMS-TRACE` را بگیر و بفرست تا مرحله دقیق کرش مشخص شود.

## مجوز و انتساب

این پروژه از `libbox` متعلق به sing-box استفاده می‌کند. libbox و sing-box تحت GPL-3.0-or-later منتشر می‌شوند. توزیع نسخه‌ای که libbox را در خود دارد باید الزامات مجوز GPL، شامل ارائه کد منبع متناظر و حفظ اعلان‌های حق نشر و مجوز را رعایت کند.

- libbox: https://github.com/singbox-android/libbox
- sing-box: https://github.com/SagerNet/sing-box
- Android client reference: https://github.com/SagerNet/sing-box-for-android
