plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.alishams.vpn"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.alishams.vpn"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "3.2-fix"
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86_64")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf("META-INF/**", "**/kotlin-tooling-metadata.json")
        }
    }
}
dependencies {
    // latest stable libbox that matches sing-box 1.14.x
    implementation("com.github.singbox-android:libbox:1.14.4")
    implementation("androidx.core:core-ktx:1.15.0")
}
