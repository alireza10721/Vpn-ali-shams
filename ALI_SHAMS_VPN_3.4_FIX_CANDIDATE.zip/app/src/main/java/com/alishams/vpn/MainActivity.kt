package com.alishams.vpn

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Base64
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val executor = Executors.newFixedThreadPool(6)
    private var pendingConfig: String? = null
    private val vpnRequestCode = 7101
    private var waitingForInternetTest = false

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != SingBoxVpnService.ACTION_STATE) return
            val ok = intent.getBooleanExtra(SingBoxVpnService.EXTRA_OK, false)
            val message = intent.getStringExtra(SingBoxVpnService.EXTRA_MESSAGE) ?: ""
            if (ok && waitingForInternetTest) {
                waitingForInternetTest = false
                executor.execute {
                    Thread.sleep(1800)
                    val success = verifyInternetThroughTunnel()
                    runOnUiThread {
                        if (success) notifyState(true, "اتصال sing-box و عبور واقعی اینترنت تأیید شد.")
                        else {
                            stopVpnService()
                            notifyState(false, "موتور اجرا شد، اما عبور اینترنت از تونل تأیید نشد. سرور سبز اعلام نشد.")
                        }
                    }
                }
            } else if (!ok) {
                waitingForInternetTest = false
                notifyState(false, message)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Diagnostics.write(this, "MainActivity onCreate; SDK=${Build.VERSION.SDK_INT}; device=${Build.MANUFACTURER} ${Build.MODEL}")
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Diagnostics.write(applicationContext, "UNCAUGHT EXCEPTION on thread=${thread.name}", throwable)
            android.os.Process.killProcess(android.os.Process.myPid())
        }
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        val filter = IntentFilter(SingBoxVpnService.ACTION_STATE)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(stateReceiver, filter)
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun refreshServers() {
            executor.execute {
                val collected = java.util.Collections.synchronizedList(mutableListOf<JSONObject>())
                val seen = java.util.Collections.synchronizedSet(mutableSetOf<String>())
                val sources = listOf(
                    "Morpheus WG" to listOf("https://raw.githubusercontent.com/morpheusadam/v2ray-config/main/subs/bundles/wireguard.txt"),
                    "Au1rxx Free" to listOf("https://raw.githubusercontent.com/Au1rxx/free-vpn-subscriptions/main/output/singbox.json"),
                    "0xRadikal Free" to listOf("https://raw.githubusercontent.com/0xRadikal/Free-v2ray-Configs/main/verified/singbox.json"),
                    "V2RayAggregator" to listOf("https://raw.githubusercontent.com/mahdibland/V2RayAggregator/master/sub/sub_merge.txt"),
                    "NoMoreWalls" to listOf("https://raw.githubusercontent.com/peasoft/NoMoreWalls/master/list.txt"),
                    "Fly Free Nodes" to listOf("https://raw.githubusercontent.com/ts-sf/fly/main/v2"),
                    "Barry Far" to listOf("https://raw.githubusercontent.com/barry-far/V2ray-Config/main/All_Configs_Sub.txt")
                )
                val pool = Executors.newFixedThreadPool(sources.size)
                val tasks = sources.map { (source, urls) ->
                    pool.submit {
                        try {
                            val body = fetchFirstAvailable(urls)
                            val normalized = decodeSubscription(body)
                            val parsed = parseSourceContent(normalized)
                            parsed.forEach { node ->
                                val key = "${node.protocol}|${node.host.lowercase()}|${node.port}"
                                if (seen.add(key)) {
                                    val item = JSONObject()
                                    item.put("name", node.name)
                                    item.put("endpoint", "${node.host}:${node.port}")
                                    item.put("host", node.host)
                                    item.put("port", node.port)
                                    item.put("protocol", node.protocol)
                                    item.put("config", node.json)
                                    item.put("source", source)
                                    item.put("flag", flagFor(node.name))
                                    item.put("pingMs", -1)
                                    collected.add(item)
                                }
                            }
                        } catch (_: Exception) { }
                    }
                }
                pool.shutdown()
                pool.awaitTermination(11, TimeUnit.SECONDS)
                pool.shutdownNow()

                // ICMP round-trip measurement is a reachability hint only, not a VPN success test.
                val pingPool = Executors.newFixedThreadPool(18)
                val pingTasks = collected.map { item ->
                    item to pingPool.submit<Long> { measureIcmpPing(item.optString("host")) }
                }
                val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(6)
                pingTasks.forEach { (item, future) ->
                    try {
                        val left = deadline - System.nanoTime()
                        if (left > 0) item.put("pingMs", future.get(left, TimeUnit.NANOSECONDS))
                    } catch (_: Exception) { item.put("pingMs", -1) }
                }
                pingPool.shutdownNow()

                val result = JSONArray()
                collected.sortedWith(compareBy<JSONObject>({ if (it.optLong("pingMs", -1) >= 0) 0 else 1 }, { it.optLong("pingMs", Long.MAX_VALUE) }))
                    .take(500).forEach { result.put(it) }
                runOnUiThread {
                    web.evaluateJavascript("window.onServersLoaded($result);", null)
                    web.evaluateJavascript("window.onNativeMessage('منابع عمومی رایگان: ${sources.size} • کانفیگ‌های سازگار جمع‌آوری‌شده: ${result.length()} • پینگ ICMP فقط نشانه دسترسی شبکه است؛ سلامت VPN فقط بعد از تست تونل مشخص می‌شود.');", null)
                    web.evaluateJavascript("document.getElementById('refresh').disabled=false;document.getElementById('refresh').textContent='⟳ بروزرسانی سرورها';", null)
                }
            }
        }

        @JavascriptInterface
        fun connect(config: String) { runOnUiThread { requestConnect(config) } }

        @JavascriptInterface
        fun importConfig(raw: String) {
            val decoded = decodeSubscription(raw)
            val parsed = SingBoxConfig.fromLink(decoded.trim()) ?: parseSourceContent(decoded).firstOrNull()
            runOnUiThread {
                if (parsed != null) {
                    val quoted = JSONObject.quote(parsed.json)
                    val label = JSONObject.quote(parsed.name + " • " + parsed.protocol)
                    web.evaluateJavascript("window.onImportedConfig($quoted, $label);", null)
                } else {
                    web.evaluateJavascript("window.onImportError('این فایل یا لینک پشتیبانی نشد. لینک‌های VLESS، VMess، Trojan، Shadowsocks، Hysteria2، TUIC و WireGuard قابل‌خواندن هستند.');", null)
                }
            }
        }

        @JavascriptInterface
        fun disconnect() { stopVpnService(); notifyState(false, "اتصال قطع شد.") }

        @JavascriptInterface
        fun shareDiagnostics() {
            val report = Diagnostics.read(this@MainActivity)
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "ALI SHAMS VPN diagnostics")
                    putExtra(Intent.EXTRA_TEXT, report)
                }
                startActivity(Intent.createChooser(send, "ارسال گزارش خطا"))
            }
        }

        @JavascriptInterface
        fun clearDiagnostics() { Diagnostics.clear(this@MainActivity) }
    }

    private fun parseSourceContent(content: String): List<SingBoxConfig.Parsed> {
        val result = mutableListOf<SingBoxConfig.Parsed>()
        val trimmed = content.trim()
        if (trimmed.startsWith("{")) {
            runCatching {
                val root = JSONObject(trimmed)
                val outbounds = root.optJSONArray("outbounds")
                if (outbounds != null) for (i in 0 until outbounds.length()) {
                    SingBoxConfig.fromSingBoxOutbound(outbounds.optJSONObject(i) ?: continue)?.let { result.add(it) }
                }
                val endpoints = root.optJSONArray("endpoints")
                if (endpoints != null) for (i in 0 until endpoints.length()) {
                    SingBoxConfig.fromSingBoxEndpoint(endpoints.optJSONObject(i) ?: continue)?.let { result.add(it) }
                }
            }
            if (result.isNotEmpty()) return result
        }
        val links = Regex("(?:vless|vmess|trojan|ss|hysteria2|hy2|tuic|wireguard|anytls)://[^\\s\\\"<>]+", RegexOption.IGNORE_CASE)
        links.findAll(content).take(1200).forEach { match -> SingBoxConfig.fromLink(match.value.trimEnd(',', ';', ')', ']'))?.let { result.add(it) } }
        return result
    }

    private fun wrapOutbound(outbound: JSONObject): String {
        val node = SingBoxConfig.fromSingBoxOutbound(outbound) ?: return "{}"
        return node.json
    }

    private fun decodeSubscription(body: String): String {
        val t = body.trim()
        if (t.startsWith("{") || t.contains("://")) return t
        val compact = t.replace("\\s".toRegex(), "")
        return runCatching { String(Base64.getMimeDecoder().decode(compact), Charsets.UTF_8) }.getOrDefault(body)
    }

    private fun fetchFirstAvailable(urls: List<String>): String {
        var last: Exception? = null
        urls.forEach { address ->
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(address).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 4000; readTimeout = 5500; requestMethod = "GET"
                    setRequestProperty("User-Agent", "ALI-SHAMS-VPN/3.0")
                    setRequestProperty("Accept", "text/plain, application/json, */*")
                }
                if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
                return conn.inputStream.bufferedReader().use { it.readText() }
            } catch (e: Exception) { last = e } finally { conn?.disconnect() }
        }
        throw last ?: IllegalStateException("No free source available")
    }

    private fun measureIcmpPing(host: String): Long {
        if (host.isBlank()) return -1
        return try {
            val p = ProcessBuilder("/system/bin/ping", "-c", "1", "-W", "1", host).redirectErrorStream(true).start()
            val output = p.inputStream.bufferedReader().use { it.readText() }
            p.waitFor(1300, TimeUnit.MILLISECONDS)
            p.destroy()
            Regex("time[=<]([0-9.]+)\\s*ms", RegexOption.IGNORE_CASE).find(output)?.groupValues?.get(1)?.toDoubleOrNull()?.toLong() ?: -1
        } catch (_: Exception) { -1 }
    }

    private fun flagFor(name: String): String {
        val n = name.lowercase()
        fun code(value: String) = Regex("(^|[^a-z])$value([^a-z]|$)").containsMatchIn(n)
        return when {
            "germany" in n || code("de") -> "🇩🇪"
            "united states" in n || "usa" in n || code("us") -> "🇺🇸"
            "united kingdom" in n || code("uk") || "britain" in n -> "🇬🇧"
            "netherlands" in n || code("nl") -> "🇳🇱"
            "france" in n || code("fr") -> "🇫🇷"
            "canada" in n || code("ca") -> "🇨🇦"
            "japan" in n || code("jp") -> "🇯🇵"
            "singapore" in n || code("sg") -> "🇸🇬"
            else -> "🌐"
        }
    }

    private fun requestConnect(config: String) {
        Diagnostics.write(this, "requestConnect called; configLength=${config.length}")
        pendingConfig = config
        val permission = VpnService.prepare(this)
        if (permission != null) {
            @Suppress("DEPRECATION")
            startActivityForResult(permission, vpnRequestCode)
        } else startSingBox(config)
    }

    @Deprecated("Legacy VPN consent callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequestCode) {
            val config = pendingConfig
            if (resultCode == RESULT_OK && config != null) startSingBox(config)
            else notifyState(false, "مجوز VPN صادر نشد.")
        }
    }

    private fun startSingBox(config: String) {
        Diagnostics.write(this, "startSingBox; configLength=${config.length}")
        try {
            waitingForInternetTest = true
            val intent = Intent(this, SingBoxVpnService::class.java).setAction(SingBoxVpnService.ACTION_START)
                .putExtra(SingBoxVpnService.EXTRA_CONFIG, config)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            web.evaluateJavascript("window.onVpnConnecting && window.onVpnConnecting();", null)
        } catch (e: Exception) {
            Diagnostics.write(this, "startSingBox exception", e)
            waitingForInternetTest = false
            notifyState(false, "شروع VPN ناموفق: ${e.message}")
        }
    }

    private fun stopVpnService() {
        waitingForInternetTest = false
        startService(Intent(this, SingBoxVpnService::class.java).setAction(SingBoxVpnService.ACTION_STOP))
    }

    private fun verifyInternetThroughTunnel(): Boolean {
        val urls = listOf("https://www.gstatic.com/generate_204", "https://cp.cloudflare.com/generate_204", "https://connectivitycheck.gstatic.com/generate_204")
        for (address in urls) {
            var c: HttpURLConnection? = null
            try {
                c = (URL(address).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 4500; readTimeout = 4500; instanceFollowRedirects = false
                    requestMethod = "GET"; setRequestProperty("Cache-Control", "no-cache")
                }
                val code = c.responseCode
                if (code == 204 || code in 200..299) return true
            } catch (_: Exception) { } finally { c?.disconnect() }
        }
        return false
    }

    private fun notifyState(ok: Boolean, message: String) {
        runOnUiThread {
            val escaped = JSONObject.quote(message)
            web.evaluateJavascript("window.onVpnState($ok, $escaped);", null)
        }
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(stateReceiver) }
        if (::web.isInitialized) web.destroy()
        executor.shutdownNow()
        super.onDestroy()
    }
}
