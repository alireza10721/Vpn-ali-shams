package com.alishams.vpn

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Diagnostics {
    private const val FILE_NAME = "ali_shams_diagnostics.txt"
    @Synchronized fun write(context: Context, message: String, error: Throwable? = null) {
        runCatching {
            val file = File(context.filesDir, FILE_NAME)
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
            file.appendText("[$stamp] $message\n" + (error?.stackTraceToString()?.take(12000)?.plus("\n") ?: ""))
            if (file.length() > 180_000) file.writeText("... trimmed ...\n" + file.readText().takeLast(120_000))
        }
    }
    fun read(context: Context): String {
        val file = File(context.filesDir, FILE_NAME)
        return if (file.exists()) file.readText() else "No diagnostic events recorded yet."
    }
    fun clear(context: Context) { runCatching { File(context.filesDir, FILE_NAME).delete() } }
}
