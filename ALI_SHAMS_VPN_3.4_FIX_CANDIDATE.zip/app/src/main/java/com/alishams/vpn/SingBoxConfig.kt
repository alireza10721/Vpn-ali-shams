package com.alishams.vpn

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder

object SingBoxConfig {
    data class Parsed(val name: String, val host: String, val port: Int, val protocol: String, val json: String)

    fun fromLink(raw: String): Parsed? {
        val link = raw.trim()
        if (link.startsWith("[Interface]", true)) return fromWireGuardConf(link)
        return try {
            when {
                link.startsWith("vless://", true) -> parseVless(link)
                link.startsWith("vmess://", true) -> parseVmess(link)
                link.startsWith("trojan://", true) -> parseTrojan(link)
                link.startsWith("ss://", true) -> parseShadowsocks(link)
                link.startsWith("hysteria2://", true) || link.startsWith("hy2://", true) -> parseHysteria2(link)
                link.startsWith("tuic://", true) -> parseTuic(link)
                link.startsWith("wireguard://", true) -> parseWireGuard(link)
                link.startsWith("anytls://", true) -> parseAnyTls(link)
                else -> null
            }
        } catch (_: Exception) { null }
    }


    private fun fromWireGuardConf(text: String): Parsed? {
        return try {
            val values = mutableMapOf<String, String>()
            var section = ""
            text.lineSequence().forEach { raw ->
                val line = raw.substringBefore('#').trim()
                if (line.startsWith("[") && line.endsWith("]")) section = line.substring(1, line.length - 1).lowercase()
                else if ('=' in line) {
                    val k = line.substringBefore('=').trim().lowercase()
                    val v = line.substringAfter('=').trim()
                    values["$section.$k"] = v
                }
            }
            val privateKey = values["interface.privatekey"] ?: return null
            val address = values["interface.address"] ?: return null
            val endpoint = values["peer.endpoint"] ?: return null
            val publicKey = values["peer.publickey"] ?: return null
            val host = endpoint.substringBeforeLast(':').removePrefix("[").removeSuffix("]")
            val port = endpoint.substringAfterLast(':').toIntOrNull() ?: return null
            if (host.isBlank() || port !in 1..65535) return null
            val outbound = JSONObject().put("type", "wireguard").put("server", host).put("server_port", port)
                .put("local_address", JSONArray(address.split(',').map { it.trim() })).put("private_key", privateKey).put("peer_public_key", publicKey)
            values["peer.presharedkey"]?.let { outbound.put("pre_shared_key", it) }
            values["interface.mtu"]?.toIntOrNull()?.let { outbound.put("mtu", it) }
            val name = "WireGuard $host"
            Parsed(name, host, port, "WireGuard", wrapOutbound(outbound, name))
        } catch (_: Exception) { null }
    }

    fun fromSingBoxOutbound(outbound: JSONObject): Parsed? {
        return try {
            val type = outbound.optString("type").lowercase()
            val host = outbound.optString("server")
            val port = outbound.optInt("server_port")
            if (host.isBlank() || port !in 1..65535 || type !in setOf("vless", "vmess", "trojan", "shadowsocks", "hysteria2", "tuic", "anytls")) return null
            val name = outbound.optString("tag", type.uppercase())
            Parsed(name, host, port, type, wrapOutbound(JSONObject(outbound.toString()), name))
        } catch (_: Exception) { null }
    }

    fun fromSingBoxEndpoint(endpoint: JSONObject): Parsed? {
        return try {
            if (!endpoint.optString("type").equals("wireguard", true)) return null
            val peer = endpoint.optJSONArray("peers")?.optJSONObject(0) ?: return null
            val host = peer.optString("address")
            val port = peer.optInt("port")
            val privateKey = endpoint.optString("private_key")
            val publicKey = peer.optString("public_key")
            val address = endpoint.optJSONArray("address") ?: return null
            if (host.isBlank() || port !in 1..65535 || privateKey.isBlank() || publicKey.isBlank()) return null
            val outbound = JSONObject().put("type", "wireguard").put("server", host).put("server_port", port)
                .put("local_address", JSONArray(address.toString())).put("private_key", privateKey).put("peer_public_key", publicKey)
            peer.optString("pre_shared_key").takeIf { it.isNotBlank() }?.let { outbound.put("pre_shared_key", it) }
            endpoint.optInt("mtu").takeIf { it > 0 }?.let { outbound.put("mtu", it) }
            Parsed(endpoint.optString("tag", "WireGuard"), host, port, "WireGuard", wrapOutbound(outbound, "WireGuard"))
        } catch (_: Exception) { null }
    }

    private fun parseVless(link: String): Parsed? {
        val u = Uri.parse(link)
        val uuid = u.userInfo ?: return null
        val host = u.host ?: return null
        val port = u.port
        if (port !in 1..65535) return null
        val q = query(u)
        val tlsEnabled = q["security"]?.let { it != "none" && it != "" } ?: (q["type"] != "tcp")
        val outbound = JSONObject().put("type", "vless").put("server", host).put("server_port", port).put("uuid", uuid)
        q["flow"]?.takeIf { it.isNotBlank() }?.let { outbound.put("flow", it) }
        if (tlsEnabled) {
            val tls = JSONObject().put("enabled", true)
            tls.put("server_name", q["sni"]?.takeIf { it.isNotBlank() } ?: host)
            q["fp"]?.takeIf { it.isNotBlank() }?.let { tls.put("utls", JSONObject().put("enabled", true).put("fingerprint", it)) }
            if (q["security"] == "reality") {
                val publicKey = q["pbk"] ?: q["publicKey"] ?: return null
                val reality = JSONObject().put("enabled", true).put("public_key", publicKey)
                q["sid"]?.let { reality.put("short_id", it) }
                tls.put("reality", reality)
            }
            outbound.put("tls", tls)
        }
        addTransport(outbound, q)
        return parsed(u, host, port, "VLESS", outbound)
    }

    private fun parseVmess(link: String): Parsed? {
        val encoded = link.substringAfter("vmess://", "").substringBefore('#')
        val decoded = decodeBase64(encoded) ?: return null
        val obj = JSONObject(decoded)
        val host = obj.optString("add")
        val port = obj.optString("port").toIntOrNull() ?: return null
        val outbound = JSONObject().put("type", "vmess").put("server", host).put("server_port", port)
            .put("uuid", obj.optString("id")).put("alter_id", obj.optInt("aid", 0))
            .put("security", obj.optString("scy", "auto"))
        if (obj.optString("tls").equals("tls", true)) {
            val tls = JSONObject().put("enabled", true)
            val sni = obj.optString("sni").ifBlank { obj.optString("host") }
            if (sni.isNotBlank()) tls.put("server_name", sni)
            outbound.put("tls", tls)
        }
        val net = obj.optString("net")
        if (net == "ws") outbound.put("transport", JSONObject().put("type", "ws").put("path", obj.optString("path")).put("headers", JSONObject().put("Host", obj.optString("host"))))
        if (net == "grpc") outbound.put("transport", JSONObject().put("type", "grpc").put("service_name", obj.optString("path")))
        return Parsed(obj.optString("ps", "VMess"), host, port, "VMess", wrapOutbound(outbound, obj.optString("ps", "VMess")))
    }

    private fun parseTrojan(link: String): Parsed? {
        val u = Uri.parse(link); val host = u.host ?: return null; val port = u.port
        if (port !in 1..65535) return null
        val password = u.userInfo ?: return null; val q = query(u)
        val tls = JSONObject().put("enabled", true)
        tls.put("server_name", q["sni"]?.takeIf { it.isNotBlank() } ?: host)
        q["fp"]?.let { tls.put("utls", JSONObject().put("enabled", true).put("fingerprint", it)) }
        val outbound = JSONObject().put("type", "trojan").put("server", host).put("server_port", port).put("password", password).put("tls", tls)
        addTransport(outbound, q)
        return parsed(u, host, port, "Trojan", outbound)
    }

    private fun parseShadowsocks(link: String): Parsed? {
        val u = Uri.parse(link); var host: String? = u.host; var port: Int? = u.port; var method = ""; var password = ""
        if (host == null) {
            val decoded = decodeBase64(link.substringAfter("ss://").substringBefore('#').substringBefore('?')) ?: return null
            val at = decoded.lastIndexOf('@'); if (at < 0) return null
            val auth = decoded.substring(0, at); val hp = decoded.substring(at + 1).split(':')
            val colon = auth.indexOf(':'); if (colon < 0 || hp.size < 2) return null
            method = auth.substring(0, colon); password = auth.substring(colon + 1); host = hp[0]; port = hp[1].toIntOrNull()
        } else {
            val auth = u.userInfo ?: return null
            val decoded = decodeBase64(auth) ?: auth
            val colon = decoded.indexOf(':'); if (colon < 0) return null
            method = decoded.substring(0, colon); password = decoded.substring(colon + 1)
        }
        val finalHost = host ?: return null
        val finalPort = port ?: return null
        if (finalPort !in 1..65535 || method.isBlank() || password.isBlank()) return null
        val outbound = JSONObject().put("type", "shadowsocks").put("server", finalHost).put("server_port", finalPort).put("method", method).put("password", password)
        return Parsed(fragmentName(link, "Shadowsocks"), finalHost, finalPort, "Shadowsocks", wrapOutbound(outbound, fragmentName(link, "Shadowsocks")))
    }

    private fun parseHysteria2(link: String): Parsed? {
        val u = Uri.parse(link); val host = u.host ?: return null; val port = u.port
        if (port !in 1..65535) return null
        val password = u.userInfo ?: return null; val q = query(u)
        val tls = JSONObject().put("enabled", true)
        tls.put("server_name", q["sni"]?.takeIf { it.isNotBlank() } ?: host)
        q["insecure"]?.let { tls.put("insecure", it == "1" || it.equals("true", true)) }
        q["alpn"]?.let { tls.put("alpn", JSONArray(it.split(','))) }
        val outbound = JSONObject().put("type", "hysteria2").put("server", host).put("server_port", port).put("password", password).put("tls", tls)
        q["obfs"]?.let { obfs -> outbound.put("obfs", JSONObject().put("type", obfs).put("password", q["obfs-password"] ?: "")) }
        return parsed(u, host, port, "Hysteria2", outbound)
    }

    private fun parseTuic(link: String): Parsed? {
        val u = Uri.parse(link); val host = u.host ?: return null; val port = u.port
        if (port !in 1..65535) return null
        val auth = u.userInfo ?: return null; val bits = auth.split(':', limit = 2); if (bits.size != 2) return null
        val q = query(u); val tls = JSONObject().put("enabled", true)
        tls.put("server_name", q["sni"]?.takeIf { it.isNotBlank() } ?: host)
        val outbound = JSONObject().put("type", "tuic").put("server", host).put("server_port", port)
            .put("uuid", bits[0]).put("password", bits[1]).put("tls", tls)
        q["congestion_control"]?.let { outbound.put("congestion_control", it) }
        return parsed(u, host, port, "TUIC", outbound)
    }

    private fun parseAnyTls(link: String): Parsed? {
        val u = Uri.parse(link); val host = u.host ?: return null; val port = u.port
        if (port !in 1..65535) return null
        val outbound = JSONObject().put("type", "anytls").put("server", host).put("server_port", port).put("password", u.userInfo ?: return null)
            .put("tls", JSONObject().put("enabled", true).put("server_name", query(u)["sni"] ?: host))
        return parsed(u, host, port, "AnyTLS", outbound)
    }

    private fun parseWireGuard(link: String): Parsed? {
        val u = Uri.parse(link); val host = u.host ?: return null; val port = u.port
        if (port !in 1..65535) return null
        val q = query(u); val privateKey = u.userInfo ?: return null
        val publicKey = q["publickey"] ?: return null; val address = q["address"] ?: return null
        val outbound = JSONObject().put("type", "wireguard").put("server", host).put("server_port", port)
            .put("local_address", JSONArray(address.split(','))).put("private_key", privateKey).put("peer_public_key", publicKey)
        q["presharedkey"]?.let { outbound.put("pre_shared_key", it) }
        q["mtu"]?.toIntOrNull()?.let { outbound.put("mtu", it) }
        q["keepalive"]?.toIntOrNull()?.let { outbound.put("persistent_keepalive_interval", it) }
        return parsed(u, host, port, "WireGuard", outbound)
    }

    private fun parsed(uri: Uri, host: String, port: Int, protocol: String, outbound: JSONObject): Parsed {
        val name = fragmentName(uri.toString(), protocol)
        return Parsed(name, host, port, protocol, wrapOutbound(outbound, name))
    }

    private fun wrapOutbound(outbound: JSONObject, name: String): String {
        val isWireGuard = outbound.optString("type") == "wireguard"
        val endpoints = JSONArray()
        val outbounds = JSONArray()
        if (isWireGuard) {
            val peer = JSONObject().put("address", outbound.optString("server"))
                .put("port", outbound.optInt("server_port"))
                .put("public_key", outbound.optString("peer_public_key"))
                .put("allowed_ips", JSONArray().put("0.0.0.0/0").put("::/0"))
                .put("persistent_keepalive_interval", 25)
            outbound.optString("pre_shared_key").takeIf { it.isNotBlank() }?.let { peer.put("pre_shared_key", it) }
            val endpoint = JSONObject().put("type", "wireguard").put("tag", "wg-endpoint")
                .put("system", false).put("name", "ali-shams-wg").put("mtu", outbound.optInt("mtu", 1408))
                .put("address", outbound.optJSONArray("local_address") ?: JSONArray())
                .put("private_key", outbound.optString("private_key")).put("peers", JSONArray().put(peer))
            endpoints.put(endpoint)
            outbounds.put(JSONObject().put("type", "direct").put("tag", "direct"))
        } else {
            outbound.put("tag", "proxy")
            outbounds.put(outbound).put(JSONObject().put("type", "direct").put("tag", "direct"))
        }
        // Minimal TUN for Android VpnService + libbox 1.14
        // - no sniff* on inbound (removed in sing-box 1.13)
        // - no stack (platform-managed on Android)
        // - IPv4-only address for maximum device compatibility
        val dnsServer = if (isWireGuard) {
            JSONObject().put("type", "local").put("tag", "dns-local")
        } else {
            JSONObject()
                .put("type", "https")
                .put("tag", "dns-remote")
                .put("server", "1.1.1.1")
                .put("detour", "proxy")
        }

        val tunInbound = JSONObject()
            .put("type", "tun")
            .put("tag", "tun-in")
            .put("address", JSONArray().put("172.19.0.1/30"))
            .put("mtu", 1500)
            .put("auto_route", true)

        val routeRules = JSONArray()
            .put(JSONObject().put("action", "sniff"))
            .put(JSONObject().put("protocol", "dns").put("action", "hijack-dns"))

        val config = JSONObject()
            .put("log", JSONObject().put("level", "info"))
            .put("dns", JSONObject()
                .put("servers", JSONArray().put(dnsServer))
                .put("final", if (isWireGuard) "dns-local" else "dns-remote")
                .put("strategy", "ipv4_only"))
            .put("inbounds", JSONArray().put(tunInbound))
            .put("outbounds", outbounds)
            .put("route", JSONObject()
                .put("auto_detect_interface", true)
                .put("final", if (isWireGuard) "direct" else "proxy")
                .put("rules", routeRules))
        if (endpoints.length() > 0) config.put("endpoints", endpoints)
        return config.toString()
    }

    private fun addTransport(outbound: JSONObject, q: Map<String, String>) {
        when (q["type"]) {
            "ws" -> {
                val headers = JSONObject(); q["host"]?.let { headers.put("Host", it) }
                outbound.put("transport", JSONObject().put("type", "ws").put("path", q["path"] ?: "/").put("headers", headers))
            }
            "grpc" -> outbound.put("transport", JSONObject().put("type", "grpc").put("service_name", q["serviceName"] ?: q["service_name"] ?: ""))
            "httpupgrade" -> outbound.put("transport", JSONObject().put("type", "httpupgrade").put("host", q["host"] ?: "").put("path", q["path"] ?: "/"))
        }
    }

    private fun query(uri: Uri): Map<String, String> = (uri.queryParameterNames ?: emptySet()).associateWith { uri.getQueryParameter(it) ?: "" }
    private fun fragmentName(link: String, fallback: String): String = runCatching { URLDecoder.decode(link.substringAfter('#', ""), "UTF-8") }.getOrNull()?.takeIf { it.isNotBlank() }?.take(55) ?: fallback
    private fun decodeBase64(value: String): String? = try {
        val clean = value.replace('-', '+').replace('_', '/').replace(" ", "")
        String(Base64.decode(clean, Base64.DEFAULT), Charsets.UTF_8)
    } catch (_: Exception) { null }
}
