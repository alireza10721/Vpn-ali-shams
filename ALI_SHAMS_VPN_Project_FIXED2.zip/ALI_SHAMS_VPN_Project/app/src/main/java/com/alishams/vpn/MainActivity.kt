package com.alishams.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.Base64
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val executor = Executors.newSingleThreadExecutor()
    private var backend: GoBackend? = null
    private var pendingConfig: String? = null
    private val vpnRequestCode = 7101

    private val tunnel = object : Tunnel {
        override fun getName() = "ALI-SHAMS"
        override fun onStateChange(newState: Tunnel.State) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(this@MainActivity)
        web = WebView(this@MainActivity)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface
        fun refreshServers() {
            executor.execute {
                try {
                    val url = URL("https://raw.githubusercontent.com/morpheusadam/v2ray-config/main/subs/bundles/wireguard.txt")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 15000
                        readTimeout = 20000
                        setRequestProperty("User-Agent", "ALI-SHAMS-VPN")
                    }
                    val text = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()

                    val arr = JSONArray()
                    val seen = HashSet<String>()
                    text.lineSequence().filter { it.startsWith("wireguard://") }.take(300).forEach { line ->
                        try {
                            val parsed = parseWireGuardUri(line.trim())
                            if (parsed != null && seen.add(parsed.first)) {
                                val item = JSONObject()
                                item.put("name", parsed.second)
                                item.put("endpoint", parsed.first)
                                item.put("config", parsed.third)
                                item.put("flag", "🌐")
                                arr.put(item)
                            }
                        } catch (_: Exception) {}
                    }

                    runOnUiThread {
                        web.evaluateJavascript("window.onServersLoaded($arr);", null)
                        web.evaluateJavascript(
                            "window.onNativeMessage('دریافت انجام شد؛ سالم بودن سرورها از شبکه شما تضمین نشده است.');",
                            null
                        )
                        web.evaluateJavascript(
                            "document.getElementById('refresh').disabled=false;document.getElementById('refresh').textContent='⟳ بروزرسانی سرورها';",
                            null
                        )
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        web.evaluateJavascript(
                            "window.onNativeMessage('${js(e.message ?: "network error")}');",
                            null
                        )
                        web.evaluateJavascript(
                            "document.getElementById('refresh').disabled=false;document.getElementById('refresh').textContent='⟳ بروزرسانی سرورها';",
                            null
                        )
                    }
                }
            }
        }

        @JavascriptInterface
        fun connect(config: String) {
            runOnUiThread { requestConnect(config) }
        }

        @JavascriptInterface
        fun disconnect() {
            executor.execute {
                try {
                    backend?.setState(tunnel, Tunnel.State.DOWN, null)
                    notifyState(false, "اتصال قطع شد.")
                } catch (e: Exception) {
                    notifyState(false, "خطا در قطع اتصال: ${e.message}")
                }
            }
        }
    }

    private fun requestConnect(config: String) {
        pendingConfig = config
        val intent = VpnService.prepare(this@MainActivity)
        if (intent != null) {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, vpnRequestCode)
        } else {
            connectNow(config)
        }
    }

    @Deprecated("Deprecated in Android API, retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequestCode) {
            val config = pendingConfig
            if (resultCode == Activity.RESULT_OK && config != null) {
                connectNow(config)
            } else {
                notifyState(false, "مجوز VPN داده نشد.")
            }
        }
    }

    private fun connectNow(raw: String) {
        executor.execute {
            try {
                val config = Config.parse(ByteArrayInputStream(raw.toByteArray(StandardCharsets.UTF_8)))
                backend?.setState(tunnel, Tunnel.State.UP, config)
                notifyState(true, "درخواست اتصال ثبت شد. برای اطمینان، اینترنت و IP را بررسی کن.")
            } catch (e: Exception) {
                notifyState(false, "اتصال ناموفق: ${e.message ?: "کانفیگ یا سرور نامعتبر است"}")
            }
        }
    }

    private fun notifyState(ok: Boolean, msg: String) {
        runOnUiThread {
            web.evaluateJavascript("window.onVpnState($ok, '${js(msg)}');", null)
        }
    }

    private fun js(s: String): String =
        s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")

    private fun parseWireGuardUri(line: String): Triple<String, String, String>? {
        val uri = java.net.URI(line)
        val rawUser = uri.rawUserInfo ?: return null
        val privateKey = URLDecoder.decode(rawUser, "UTF-8")
        val host = uri.host ?: return null
        val port = uri.port
        if (port !in 1..65535) return null

        val query = linkedMapOf<String, String>()
        (uri.rawQuery ?: "").split("&").filter { it.isNotBlank() }.forEach {
            val p = it.split("=", limit = 2)
            query[URLDecoder.decode(p[0], "UTF-8")] =
                URLDecoder.decode(p.getOrElse(1) { "" }, "UTF-8")
        }

        if (query.keys.any {
                it in setOf("reserved", "wnoise", "wnoisecount", "wnoisedelay", "wpayloadsize")
            }) return null

        val publicKey = query["publickey"] ?: return null
        val address = query["address"] ?: return null
        val decoder = Base64.getDecoder()
        if (decoder.decode(privateKey).size != 32 || decoder.decode(publicKey).size != 32) return null

        val endpoint = "$host:$port"
        val name = URLDecoder.decode(uri.rawFragment ?: "Public WireGuard", "UTF-8").take(48)
        val sb = StringBuilder()
        sb.append("[Interface]\nPrivateKey = $privateKey\nAddress = $address\n")
        query["dns"]?.let { sb.append("DNS = $it\n") }
        query["mtu"]?.let { sb.append("MTU = $it\n") }
        sb.append("\n[Peer]\nPublicKey = $publicKey\n")
        query["presharedkey"]?.takeIf { it.isNotBlank() }?.let {
            sb.append("PresharedKey = $it\n")
        }
        sb.append("Endpoint = $endpoint\nAllowedIPs = 0.0.0.0/0, ::/0\n")
        query["keepalive"]?.let { sb.append("PersistentKeepalive = $it\n") }
        return Triple(endpoint, name, sb.toString())
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::web.isInitialized) web.destroy()
        executor.shutdown()
    }
}
