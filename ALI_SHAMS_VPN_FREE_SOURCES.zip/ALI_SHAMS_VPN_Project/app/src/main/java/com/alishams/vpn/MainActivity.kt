package com.alishams.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.Base64
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val executor = Executors.newSingleThreadExecutor()
    private var backend: GoBackend? = null
    private var pendingConfig: String? = null
    private val vpnRequestCode = 7101

    private val tunnel = object : Tunnel {
        override fun getName() = "ALI-SHAMS"
        override fun onStateChange(newState: Tunnel.State) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(this@MainActivity)
        web = WebView(this@MainActivity)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface
        fun refreshServers() {
            executor.execute {
                val arr = JSONArray()
                val seen = HashSet<String>()
                var sourceCount = 0
                var errors = 0

                fun addServer(name: String, endpoint: String, config: String, source: String, flag: String = "🌐") {
                    if (seen.add(endpoint.lowercase())) {
                        val item = JSONObject()
                        item.put("name", name)
                        item.put("endpoint", endpoint)
                        item.put("config", config)
                        item.put("source", source)
                        item.put("flag", flag)
                        arr.put(item)
                    }
                }

                val sources = listOf(
                    "morpheusadam" to listOf(
                        "https://raw.githubusercontent.com/morpheusadam/v2ray-config/main/subs/bundles/wireguard.txt",
                        "https://cdn.jsdelivr.net/gh/morpheusadam/v2ray-config@main/subs/bundles/wireguard.txt"
                    ),
                    "Au1rxx" to listOf(
                        "https://raw.githubusercontent.com/Au1rxx/free-vpn-subscriptions/main/output/singbox.json",
                        "https://cdn.jsdelivr.net/gh/Au1rxx/free-vpn-subscriptions@main/output/singbox.json"
                    ),
                    "0xRadikal" to listOf(
                        "https://raw.githubusercontent.com/0xRadikal/Free-v2ray-Configs/main/verified/singbox.json",
                        "https://cdn.jsdelivr.net/gh/0xRadikal/Free-v2ray-Configs@main/verified/singbox.json"
                    ),
                    "Free Nodes Radar" to listOf(
                        "https://radarhub.top/sing-box.json"
                    )
                )

                for ((sourceName, urls) in sources) {
                    try {
                        val body = fetchFirstAvailable(urls)
                        var addedFromSource = 0
                        if (sourceName == "morpheusadam") {
                            body.lineSequence().map { it.trim() }
                                .filter { it.startsWith("wireguard://", ignoreCase = true) }
                                .take(700)
                                .forEach { line ->
                                    try {
                                        val parsed = parseWireGuardUri(line)
                                        if (parsed != null) {
                                            val before = arr.length()
                                            addServer(parsed.second, parsed.first, parsed.third, sourceName)
                                            if (arr.length() > before) addedFromSource++
                                        }
                                    } catch (_: Exception) { }
                                }
                        } else {
                            val root = JSONObject(body)
                            // Au1rxx publishes sing-box WireGuard endpoints in this compact schema.
                            val endpoints = root.optJSONArray("endpoints")
                            if (endpoints != null) {
                                for (i in 0 until endpoints.length()) {
                                    try {
                                        val obj = endpoints.getJSONObject(i)
                                        if (!obj.optString("type").equals("wireguard", true)) continue
                                        val peers = obj.optJSONArray("peers") ?: continue
                                        if (peers.length() == 0) continue
                                        val peer = peers.getJSONObject(0)
                                        // Reserved bytes are a non-standard WireGuard extension; do not
                                        // feed them to the standard WireGuard engine as if compatible.
                                        if (peer.optString("reserved").isNotBlank()) continue
                                        val privateKey = obj.optString("private_key")
                                        val publicKey = peer.optString("public_key")
                                        val host = peer.optString("address")
                                        val port = peer.optInt("port", 0)
                                        val addresses = obj.optJSONArray("address") ?: continue
                                        val localAddress = if (addresses.length() > 0) addresses.optString(0) else ""
                                        if (privateKey.isBlank() || publicKey.isBlank() || host.isBlank() || port !in 1..65535 || localAddress.isBlank()) continue
                                        if (decodeKeySize(privateKey) != 32 || decodeKeySize(publicKey) != 32) continue
                                        val endpoint = "$host:$port"
                                        val conf = "[Interface]\nPrivateKey = $privateKey\nAddress = $localAddress\nDNS = 1.1.1.1\n\n[Peer]\nPublicKey = $publicKey\nEndpoint = $endpoint\nAllowedIPs = 0.0.0.0/0, ::/0\nPersistentKeepalive = 25\n"
                                        val before = arr.length()
                                        addServer(obj.optString("tag", "WireGuard"), endpoint, conf, sourceName)
                                        if (arr.length() > before) addedFromSource++
                                    } catch (_: Exception) { }
                                }
                            }
                            // Generic sing-box subscription JSON: accept only standard WireGuard outbounds.
                            val outbounds = root.optJSONArray("outbounds")
                            if (outbounds != null) {
                                for (i in 0 until outbounds.length()) {
                                    try {
                                        val obj = outbounds.getJSONObject(i)
                                        if (!obj.optString("type").equals("wireguard", true)) continue
                                        val privateKey = obj.optString("private_key")
                                        val publicKey = obj.optString("peer_public_key", obj.optString("public_key"))
                                        val host = obj.optString("server")
                                        val port = obj.optInt("server_port", 0)
                                        val addr = obj.optJSONArray("local_address") ?: obj.optJSONArray("address")
                                        val localAddress = if (addr != null && addr.length() > 0) addr.optString(0) else obj.optString("address")
                                        if (obj.optString("reserved").isNotBlank()) continue
                                        if (privateKey.isBlank() || publicKey.isBlank() || host.isBlank() || port !in 1..65535 || localAddress.isBlank()) continue
                                        if (decodeKeySize(privateKey) != 32 || decodeKeySize(publicKey) != 32) continue
                                        val endpoint = "$host:$port"
                                        val conf = "[Interface]\nPrivateKey = $privateKey\nAddress = $localAddress\nDNS = 1.1.1.1\n\n[Peer]\nPublicKey = $publicKey\nEndpoint = $endpoint\nAllowedIPs = 0.0.0.0/0, ::/0\nPersistentKeepalive = 25\n"
                                        val before = arr.length()
                                        addServer(obj.optString("tag", "WireGuard"), endpoint, conf, sourceName)
                                        if (arr.length() > before) addedFromSource++
                                    } catch (_: Exception) { }
                                }
                            }
                        }
                        if (addedFromSource > 0 || body.isNotBlank()) sourceCount++
                    } catch (_: Exception) {
                        errors++
                    }
                }

                runOnUiThread {
                    web.evaluateJavascript("window.onServersLoaded($arr);", null)
                    val status = "منابع رایگان بررسی‌شده: $sourceCount از ${sources.size} • خطای دریافت: $errors • فقط کانفیگ‌های WireGuard استاندارد نمایش داده می‌شوند."
                    web.evaluateJavascript("window.onNativeMessage('${js(status)}');", null)
                    web.evaluateJavascript(
                        "document.getElementById('refresh').disabled=false;document.getElementById('refresh').textContent='⟳ بروزرسانی سرورها';",
                        null
                    )
                }
            }
        }

        @JavascriptInterface
        fun connect(config: String) {
            runOnUiThread { requestConnect(config) }
        }

        @JavascriptInterface
        fun disconnect() {
            executor.execute {
                try {
                    backend?.setState(tunnel, Tunnel.State.DOWN, null)
                    notifyState(false, "اتصال قطع شد.")
                } catch (e: Exception) {
                    notifyState(false, "خطا در قطع اتصال: ${e.message}")
                }
            }
        }
    }

    private fun requestConnect(config: String) {
        pendingConfig = config
        val intent = VpnService.prepare(this@MainActivity)
        if (intent != null) {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, vpnRequestCode)
        } else {
            connectNow(config)
        }
    }

    @Deprecated("Deprecated in Android API, retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequestCode) {
            val config = pendingConfig
            if (resultCode == Activity.RESULT_OK && config != null) {
                connectNow(config)
            } else {
                notifyState(false, "مجوز VPN داده نشد.")
            }
        }
    }

    private fun connectNow(raw: String) {
        executor.execute {
            try {
                val config = Config.parse(ByteArrayInputStream(raw.toByteArray(StandardCharsets.UTF_8)))
                backend?.setState(tunnel, Tunnel.State.UP, config)
                notifyState(true, "درخواست اتصال ثبت شد. برای اطمینان، اینترنت و IP را بررسی کن.")
            } catch (e: Exception) {
                notifyState(false, "اتصال ناموفق: ${e.message ?: "کانفیگ یا سرور نامعتبر است"}")
            }
        }
    }

    private fun notifyState(ok: Boolean, msg: String) {
        runOnUiThread {
            web.evaluateJavascript("window.onVpnState($ok, '${js(msg)}');", null)
        }
    }

    private fun js(s: String): String =
        s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")

    private fun fetchFirstAvailable(urls: List<String>): String {
        var lastError: Exception? = null
        for (url in urls) {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 5500
                    readTimeout = 7000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "ALI-SHAMS-VPN/2.0")
                    setRequestProperty("Accept", "text/plain, application/json, */*")
                }
                if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
                return conn.inputStream.bufferedReader().use { it.readText() }
            } catch (e: Exception) {
                lastError = e
            } finally {
                conn?.disconnect()
            }
        }
        throw lastError ?: IllegalStateException("No source available")
    }

    private fun urlDecodePreservingPlus(value: String): String = URLDecoder.decode(value.replace("+", "%2B"), "UTF-8")

    private fun decodeKeySize(value: String): Int = try {
        Base64.getDecoder().decode(value).size
    } catch (_: Exception) { -1 }

    private fun parseWireGuardUri(line: String): Triple<String, String, String>? {
        val uri = java.net.URI(line)
        val rawUser = uri.rawUserInfo ?: return null
        val privateKey = urlDecodePreservingPlus(rawUser)
        val host = uri.host ?: return null
        val port = uri.port
        if (port !in 1..65535) return null

        val query = linkedMapOf<String, String>()
        (uri.rawQuery ?: "").split("&").filter { it.isNotBlank() }.forEach {
            val p = it.split("=", limit = 2)
            query[urlDecodePreservingPlus(p[0])] =
                urlDecodePreservingPlus(p.getOrElse(1) { "" })
        }

        if (query.keys.any {
                it in setOf("reserved", "wnoise", "wnoisecount", "wnoisedelay", "wpayloadsize")
            }) return null

        val publicKey = query["publickey"] ?: return null
        val address = query["address"] ?: return null
        val decoder = Base64.getDecoder()
        if (decoder.decode(privateKey).size != 32 || decoder.decode(publicKey).size != 32) return null

        val endpoint = "$host:$port"
        val name = urlDecodePreservingPlus(uri.rawFragment ?: "Public WireGuard").take(48)
        val sb = StringBuilder()
        sb.append("[Interface]\nPrivateKey = $privateKey\nAddress = $address\n")
        query["dns"]?.let { sb.append("DNS = $it\n") }
        query["mtu"]?.let { sb.append("MTU = $it\n") }
        sb.append("\n[Peer]\nPublicKey = $publicKey\n")
        query["presharedkey"]?.takeIf { it.isNotBlank() }?.let {
            sb.append("PresharedKey = $it\n")
        }
        sb.append("Endpoint = $endpoint\nAllowedIPs = 0.0.0.0/0, ::/0\n")
        query["keepalive"]?.let { sb.append("PersistentKeepalive = $it\n") }
        return Triple(endpoint, name, sb.toString())
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::web.isInitialized) web.destroy()
        executor.shutdown()
    }
}
