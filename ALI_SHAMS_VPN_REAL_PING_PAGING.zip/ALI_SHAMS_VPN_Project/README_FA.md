# ALI SHAMS VPN

پروژه شروع اندروید برای رابط فارسی + موتور WireGuard رسمی + دریافت فهرست عمومی WireGuard.

## قابلیت‌های فعلی
- رابط HTML قبلی بازطراحی شده و در WebView اجرا می‌شود.
- بروزرسانی فهرست عمومی از feed پروژه morpheusadam/v2ray-config.
- تبدیل فقط URIهای WireGuard استاندارد به فرمت `.conf`. کانفیگ‌های دارای پارامترهای اختصاصی/مبهم مانند `reserved` و `wnoise` عمداً حذف می‌شوند تا اشتباهاً اتصال خراب ساخته نشود.
- اتصال/قطع با کتابخانه رسمی WireGuard tunnel.
- وارد کردن کانفیگ اختصاصی با فایل `.conf`.

## محدودیت‌های مهم
- فهرست عمومی شخص ثالث است؛ مالک این سرورها نیستیم و امنیت، سرعت، مجاز بودن یا پایداری آن‌ها تضمین نمی‌شود.
- داده‌های عمومی ممکن است شامل کلیدهای خصوصی منتشرشده باشند. برای کار حساس از آن‌ها استفاده نکنید.
- انتخاب «سریع‌ترین» در این نسخه به معنی انتخاب اولین کانفیگ استاندارد در فهرست است، نه تست واقعی پینگ/Handshake. پینگ ICMP به تنهایی سلامت تونل را ثابت نمی‌کند.
- بخش سرور اختصاصی به معنی ایجاد خودکار VPS نیست. برای آن باید در سرویس ابری حساب بسازید، محدودیت رایگان را بررسی کنید، سرور Ubuntu را راه‌اندازی و فایل client.conf خودتان را وارد کنید.
- APK با GitHub Actions ساخته می‌شود؛ این محیط فایل APK نهایی را از پیش کامپایل نکرده است.

## ساخت APK با گوشی
1. فایل ZIP را در GitHub با نام مخزن `ali-shams-vpn` آپلود و Extract کنید (یا فایل‌ها را در مخزن قرار دهید).
2. مطمئن شوید پوشه `.github/workflows` نیز آپلود شده است.
3. در GitHub وارد Actions شوید و اجرای workflow با نام `Build ALI SHAMS VPN APK` را باز کنید.
4. پس از پایان موفق، در بخش Artifacts فایل `ALI-SHAMS-VPN-debug-apk` را دانلود کنید.
5. ZIP آرتیفکت را باز کنید و APK را روی گوشی نصب کنید. ممکن است لازم باشد نصب از منبع ناشناس را برای مرورگر/فایل‌منیجر مجاز کنید.
6. بار اول اتصال، پنجره سیستمی Android برای اجازه VPN نمایش داده می‌شود.

## ساخت محلی
با Android Studio و JDK 17:
`gradle assembleDebug`

## مجوزها
INTERNET و ACCESS_NETWORK_STATE؛ سرویس VPN با مجوز سیستمی BIND_VPN_SERVICE. مجوز VPN در اولین اتصال با تأیید کاربر صادر می‌شود.

## سرور اختصاصی
راهنمای پوشه `server/` را بخوانید. اسکریپت نصب WireGuard روی Ubuntu فقط سمت سرور را آماده می‌کند؛ سپس باید پورت UDP را در فایروال/قوانین شبکه باز کنید و فایل کلاینت را امن به گوشی منتقل کنید.


## منابع عمومی رایگان در نسخه 2

این نسخه فقط از فهرست‌های عمومی بدون پرداخت و بدون ثبت‌نام استفاده می‌کند. از هر منبع فقط ورودی‌های استاندارد WireGuard استخراج می‌شوند، چون موتور فعلی برنامه WireGuard است؛ VLESS/VMess/Trojan/Hysteria2 تا زمان اضافه‌شدن موتور sing-box قابل اتصال نیستند و عمداً به‌عنوان سرور قابل اتصال نشان داده نمی‌شوند.

- morpheusadam/v2ray-config — بسته WireGuard عمومی: https://raw.githubusercontent.com/morpheusadam/v2ray-config/main/subs/bundles/wireguard.txt
- Au1rxx/free-vpn-subscriptions — خروجی sing-box؛ فقط WireGuard استاندارد بدون فیلد reserved پذیرفته می‌شود: https://raw.githubusercontent.com/Au1rxx/free-vpn-subscriptions/main/output/singbox.json
- 0xRadikal/Free-v2ray-Configs — فهرست verified؛ فقط WireGuard در صورت وجود و سازگاری پذیرفته می‌شود: https://raw.githubusercontent.com/0xRadikal/Free-v2ray-Configs/main/verified/singbox.json
- Free Nodes Radar — خروجی sing-box؛ فقط WireGuard استاندارد در صورت وجود پذیرفته می‌شود: https://radarhub.top/sing-box.json

این‌ها سرورهای عمومی اشخاص ثالث‌اند، نه سرورهای اختصاصی یا تحت مدیریت ALI SHAMS VPN. رایگان‌بودن منبع به معنی امن یا همیشه در دسترس بودن سرور نیست. پاسخ‌دادن منبع و قابل‌اتصال بودن واقعی هر کانفیگ دو موضوع جدا هستند.
